-- Corte Certo - projeto fisico (PostgreSQL). Seguro para rodar varias vezes.
CREATE TABLE IF NOT EXISTS usuarios (
  id          SERIAL PRIMARY KEY,
  nome        VARCHAR(100) NOT NULL,
  email       VARCHAR(150) NOT NULL UNIQUE,
  senha_hash  VARCHAR(255) NOT NULL,
  criado_em   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS servicos (
  id           SERIAL PRIMARY KEY,
  nome         VARCHAR(80) NOT NULL UNIQUE,
  duracao_min  INTEGER NOT NULL CHECK (duracao_min BETWEEN 10 AND 240),
  preco        NUMERIC(8,2) NOT NULL CHECK (preco >= 0)
);

CREATE TABLE IF NOT EXISTS agendamentos (
  id          SERIAL PRIMARY KEY,
  usuario_id  INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  servico_id  INTEGER NOT NULL REFERENCES servicos(id),
  data_hora   TIMESTAMP NOT NULL,
  status      VARCHAR(12) NOT NULL DEFAULT 'agendado'
              CHECK (status IN ('agendado','concluido','cancelado')),
  observacao  VARCHAR(200),
  criado_em   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Indices (correcao do laudo: graficos/listagens lentos)
CREATE INDEX IF NOT EXISTS idx_agend_usuario_data ON agendamentos (usuario_id, data_hora);
CREATE INDEX IF NOT EXISTS idx_agend_status ON agendamentos (status);
-- Um horario so pode ter um agendamento ativo (evita duplicidade por duplo clique)
CREATE UNIQUE INDEX IF NOT EXISTS uq_agend_horario_ativo
  ON agendamentos (data_hora) WHERE status <> 'cancelado';

INSERT INTO servicos (nome, duracao_min, preco) VALUES
  ('Corte de cabelo', 30, 45.00),
  ('Barba', 20, 30.00),
  ('Corte + barba', 50, 65.00),
  ('Sobrancelha', 15, 15.00)
ON CONFLICT (nome) DO NOTHING;
