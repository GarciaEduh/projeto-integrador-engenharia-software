"""Testes unitarios/integracao. Rodar: python -m unittest  (ou: pytest)"""
import os
import tempfile
import unittest
from datetime import timedelta

from app import create_app
from app import validators as v
from app.erros import ErroValidacao


def futuro(dias=2, hora=10):
    return (v.agora() + timedelta(days=dias)).replace(hour=hora, minute=0).strftime("%Y-%m-%dT%H:%M")


class ValidatorsTest(unittest.TestCase):
    def test_data_passada_e_rejeitada(self):
        with self.assertRaises(ErroValidacao):
            v.validar_data_hora("2020-01-01T10:00")

    def test_fora_do_horario_comercial(self):
        with self.assertRaises(ErroValidacao):
            v.validar_data_hora(futuro(hora=22))

    def test_data_futura_ok(self):
        self.assertEqual(v.validar_data_hora(futuro()).replace(" ", "T"), futuro())

    def test_senha_fraca(self):
        for s in ("curta1", "somenteletras", "12345678"):
            with self.assertRaises(ErroValidacao):
                v.validar_senha(s)

    def test_email_invalido(self):
        with self.assertRaises(ErroValidacao):
            v.validar_email("sem-arroba")


class ApiTest(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.app = create_app({"DATABASE_URL": "sqlite:///" + self.path, "TESTING": True})
        self.c = self.app.test_client()

    def tearDown(self):
        os.remove(self.path)

    def registrar(self, c=None, email="ana@teste.com"):
        return (c or self.c).post("/api/auth/register",
                                  json={"nome": "Ana", "email": email, "senha": "senha1234"})

    def agendar(self, c=None, hora=10, dias=2):
        return (c or self.c).post("/api/agendamentos",
                                  json={"servico_id": 1, "data_hora": futuro(dias, hora)})

    def test_rotas_protegidas_exigem_login(self):
        self.assertEqual(self.c.get("/api/agendamentos").status_code, 401)
        self.assertEqual(self.c.get("/api/dashboard").status_code, 401)

    def test_cadastro_login_logout(self):
        self.assertEqual(self.registrar().status_code, 201)
        self.assertEqual(self.c.get("/api/auth/me").status_code, 200)
        self.c.post("/api/auth/logout")
        self.assertEqual(self.c.get("/api/auth/me").status_code, 401)
        r = self.c.post("/api/auth/login", json={"email": "ana@teste.com", "senha": "errada123"})
        self.assertEqual(r.status_code, 401)
        r = self.c.post("/api/auth/login", json={"email": "ana@teste.com", "senha": "senha1234"})
        self.assertEqual(r.status_code, 200)

    def test_email_duplicado_no_cadastro(self):
        self.registrar()
        self.assertEqual(self.registrar(self.app.test_client()).status_code, 409)

    def test_editar_perfil_com_email_repetido_retorna_409_e_nao_500(self):
        self.registrar(email="a@teste.com")
        outro = self.app.test_client()
        self.registrar(outro, email="b@teste.com")
        r = outro.put("/api/perfil", json={"nome": "Bia", "email": "a@teste.com"})
        self.assertEqual(r.status_code, 409)
        r = outro.put("/api/perfil", json={"nome": "Bia", "email": "novo@teste.com"})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["email"], "novo@teste.com")

    def test_trocar_senha(self):
        self.registrar()
        r = self.c.put("/api/perfil/senha", json={"senha_atual": "xxx", "nova_senha": "nova12345"})
        self.assertEqual(r.status_code, 422)
        r = self.c.put("/api/perfil/senha", json={"senha_atual": "senha1234", "nova_senha": "nova12345"})
        self.assertEqual(r.status_code, 200)

    def test_agendar_data_passada_retorna_422(self):
        self.registrar()
        r = self.c.post("/api/agendamentos", json={"servico_id": 1, "data_hora": "2020-01-01T10:00"})
        self.assertEqual(r.status_code, 422)
        self.assertEqual(r.get_json()["campo"], "data_hora")

    def test_duplo_clique_nao_duplica_registro(self):
        self.registrar()
        self.assertEqual(self.agendar().status_code, 201)
        self.assertEqual(self.agendar().status_code, 409)
        self.assertEqual(self.c.get("/api/agendamentos").get_json()["total"], 1)

    def test_listagem_paginacao_filtro_e_ordenacao(self):
        self.registrar()
        for h in range(8, 14):
            self.agendar(hora=h)
        r = self.c.get("/api/agendamentos?por_pagina=4&pagina=2").get_json()
        self.assertEqual((r["total"], r["paginas"], len(r["itens"])), (6, 2, 2))
        r = self.c.get("/api/agendamentos?q=barba").get_json()
        self.assertEqual(r["total"], 0)
        r = self.c.get("/api/agendamentos?ordem=data&direcao=asc").get_json()
        datas = [i["data_hora"] for i in r["itens"]]
        self.assertEqual(datas, sorted(datas))

    def test_status_exclusao_e_isolamento_entre_usuarios(self):
        self.registrar()
        ag_id = self.agendar().get_json()["id"]
        outro = self.app.test_client()
        self.registrar(outro, email="b@teste.com")
        self.assertEqual(outro.delete(f"/api/agendamentos/{ag_id}").status_code, 404)
        r = self.c.patch(f"/api/agendamentos/{ag_id}/status", json={"status": "cancelado"})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(self.agendar().status_code, 201)  # horario cancelado volta a ficar livre
        self.assertEqual(self.c.delete(f"/api/agendamentos/{ag_id}").status_code, 204)

    def test_dashboard(self):
        self.registrar()
        self.agendar()
        d = self.c.get("/api/dashboard").get_json()
        self.assertEqual(d["por_status"]["agendado"], 1)
        self.assertEqual(d["por_servico"][0]["servico"], "Corte de cabelo")
        self.assertIsNotNone(d["proximo"])

    def test_front_e_404_json(self):
        self.assertEqual(self.c.get("/").status_code, 200)
        r = self.c.get("/api/nao-existe")
        self.assertEqual((r.status_code, r.get_json()["erro"]), (404, "Recurso não encontrado."))


if __name__ == "__main__":
    unittest.main()
