from flask import Blueprint, jsonify, request, session

from ..auth import login_required
from ..erros import ErroValidacao
from ..models import usuario
from .. import validators as v

bp = Blueprint("auth", __name__, url_prefix="/api")


def _json():
    return request.get_json(silent=True) or {}


@bp.post("/auth/register")
def registrar():
    d = _json()
    uid = usuario.criar(v.validar_nome(d.get("nome")), v.validar_email(d.get("email")),
                        v.validar_senha(d.get("senha")))
    session.clear()
    session["uid"] = uid
    return jsonify(usuario.por_id(uid)), 201


@bp.post("/auth/login")
def entrar():
    d = _json()
    u = usuario.autenticar((d.get("email") or "").strip().lower(), d.get("senha") or "")
    if not u:
        return jsonify(erro="E-mail ou senha incorretos."), 401
    session.clear()
    session["uid"] = u["id"]
    return jsonify(usuario.por_id(u["id"]))


@bp.post("/auth/logout")
def sair():
    session.clear()
    return "", 204


@bp.get("/auth/me")
@login_required
def eu():
    u = usuario.por_id(session["uid"])
    if not u:
        session.clear()
        return jsonify(erro="Sessão expirada."), 401
    return jsonify(u)


@bp.put("/perfil")
@login_required
def atualizar_perfil():
    d = _json()
    usuario.atualizar(session["uid"], v.validar_nome(d.get("nome")), v.validar_email(d.get("email")))
    return jsonify(usuario.por_id(session["uid"]))


@bp.put("/perfil/senha")
@login_required
def trocar_senha():
    d = _json()
    nova = v.validar_senha(d.get("nova_senha"))
    if not usuario.trocar_senha(session["uid"], d.get("senha_atual") or "", nova):
        raise ErroValidacao("A senha atual está incorreta.", "senha_atual")
    return jsonify(ok=True)
