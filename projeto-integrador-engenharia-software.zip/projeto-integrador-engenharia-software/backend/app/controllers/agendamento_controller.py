from flask import Blueprint, jsonify, request, session

from ..auth import login_required
from ..erros import ErroValidacao
from ..models import agendamento as ag
from .. import validators as v

bp = Blueprint("agendamentos", __name__, url_prefix="/api")


@bp.get("/saude")
def saude():
    return jsonify(ok=True)


@bp.get("/servicos")
def servicos():
    return jsonify(ag.servicos())


@bp.get("/dashboard")
@login_required
def dashboard():
    return jsonify(ag.resumo(session["uid"]))


@bp.get("/agendamentos")
@login_required
def listar():
    pagina = max(1, request.args.get("pagina", 1, type=int))
    por_pagina = min(50, max(1, request.args.get("por_pagina", 8, type=int)))
    return jsonify(ag.listar(session["uid"], pagina, por_pagina,
                             request.args.get("status"), (request.args.get("q") or "").strip()[:60],
                             request.args.get("ordem", "data"), request.args.get("direcao", "desc")))


@bp.post("/agendamentos")
@login_required
def criar():
    d = request.get_json(silent=True) or {}
    try:
        servico_id = int(d.get("servico_id"))
    except (TypeError, ValueError):
        raise ErroValidacao("Escolha um serviço.", "servico_id")
    obs = (d.get("observacao") or "").strip()
    if len(obs) > 200:
        raise ErroValidacao("A observação pode ter até 200 caracteres.", "observacao")
    novo = ag.criar(session["uid"], servico_id, v.validar_data_hora(d.get("data_hora")), obs or None)
    return jsonify(id=novo), 201


@bp.patch("/agendamentos/<int:ag_id>/status")
@login_required
def status(ag_id):
    novo = (request.get_json(silent=True) or {}).get("status")
    if novo not in ag.STATUS:
        raise ErroValidacao("Status inválido.", "status")
    ag.mudar_status(session["uid"], ag_id, novo)
    return jsonify(ok=True)


@bp.delete("/agendamentos/<int:ag_id>")
@login_required
def excluir(ag_id):
    ag.excluir(session["uid"], ag_id)
    return "", 204
