"""Validacoes de entrada (usadas pelos controllers; o front-end repete as mesmas regras)."""
import os
import re
from datetime import datetime, timedelta, timezone

from .erros import ErroValidacao

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
ABRE, FECHA = 8, 20  # horario comercial: 08:00 ate 19:59


def agora():
    """Horario local do negocio (Brasilia), sem tzinfo. O servidor roda em UTC."""
    try:
        from zoneinfo import ZoneInfo
        t = datetime.now(ZoneInfo(os.environ.get("TZ_NEGOCIO", "America/Sao_Paulo")))
    except Exception:
        t = datetime.now(timezone.utc) - timedelta(hours=3)
    return t.replace(tzinfo=None, second=0, microsecond=0)


def validar_nome(v):
    v = (v or "").strip()
    if not 2 <= len(v) <= 100:
        raise ErroValidacao("Informe seu nome (de 2 a 100 caracteres).", "nome")
    return v


def validar_email(v):
    v = (v or "").strip().lower()
    if len(v) > 150 or not EMAIL_RE.match(v):
        raise ErroValidacao("Informe um e-mail válido.", "email")
    return v


def validar_senha(v):
    v = v or ""
    if len(v) < 8 or not re.search(r"[A-Za-z]", v) or not re.search(r"\d", v):
        raise ErroValidacao("A senha precisa ter 8 ou mais caracteres, com letras e números.", "senha")
    return v


def validar_data_hora(v, ref=None):
    """Aceita 'AAAA-MM-DDTHH:MM'. Exige data futura e horario comercial."""
    try:
        dt = datetime.fromisoformat(str(v).strip().replace(" ", "T"))
    except ValueError:
        raise ErroValidacao("Informe uma data e hora válidas.", "data_hora")
    dt = dt.replace(second=0, microsecond=0, tzinfo=None)
    if dt <= (ref or agora()):
        raise ErroValidacao("Escolha uma data e hora no futuro.", "data_hora")
    if not ABRE <= dt.hour < FECHA:
        raise ErroValidacao(f"Atendemos das {ABRE:02d}h às {FECHA:02d}h.", "data_hora")
    return dt.strftime("%Y-%m-%d %H:%M")
