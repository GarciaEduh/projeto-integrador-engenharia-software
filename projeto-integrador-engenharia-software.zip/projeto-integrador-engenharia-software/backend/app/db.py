"""Acesso a dados: PostgreSQL em producao (DATABASE_URL) e SQLite em testes/dev."""
import os
import sqlite3
from datetime import datetime
from decimal import Decimal

from flask import current_app, g

from .erros import Conflito

RAIZ = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


def _pg():
    return current_app.config["DATABASE_URL"].startswith(("postgres://", "postgresql://"))


def get_db():
    if "db" not in g:
        url = current_app.config["DATABASE_URL"]
        if _pg():
            import psycopg2
            import psycopg2.extras
            g.db = psycopg2.connect(url.replace("postgres://", "postgresql://", 1),
                                    cursor_factory=psycopg2.extras.RealDictCursor)
        else:
            g.db = sqlite3.connect(url.replace("sqlite:///", "", 1))
            g.db.row_factory = sqlite3.Row
            g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(_exc=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def _sql(sql):
    return sql.replace("?", "%s") if _pg() else sql


def _limpa(row):
    out = {}
    for k, v in dict(row).items():
        if isinstance(v, datetime):
            v = v.strftime("%Y-%m-%d %H:%M")
        elif isinstance(v, Decimal):
            v = float(v)
        out[k] = v
    return out


def query(sql, params=(), one=False):
    cur = get_db().cursor()
    try:
        cur.execute(_sql(sql), params)
        rows = [_limpa(r) for r in cur.fetchall()]
    finally:
        cur.close()
    return (rows[0] if rows else None) if one else rows


def execute(sql, params=(), returning=False):
    """Retorna o id criado (returning=True) ou o numero de linhas afetadas."""
    conn = get_db()
    cur = conn.cursor()
    erros = (sqlite3.IntegrityError,)
    if _pg():
        import psycopg2
        erros += (psycopg2.IntegrityError,)
    try:
        cur.execute(_sql(sql) + (" RETURNING id" if returning and _pg() else ""), params)
        if returning:
            resultado = cur.fetchone()["id"] if _pg() else cur.lastrowid
        else:
            resultado = cur.rowcount
        conn.commit()
        return resultado
    except erros as e:
        conn.rollback()
        raise Conflito(str(e)) from e
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()


def init_db():
    with open(os.path.join(RAIZ, "database", "schema.sql"), encoding="utf-8") as f:
        sql = f.read()
    conn = get_db()
    if _pg():
        cur = conn.cursor()
        cur.execute(sql)
        conn.commit()
        cur.close()
    else:
        conn.executescript(sql.replace("SERIAL PRIMARY KEY", "INTEGER PRIMARY KEY AUTOINCREMENT"))
        conn.commit()


def init_app(app):
    app.teardown_appcontext(close_db)
