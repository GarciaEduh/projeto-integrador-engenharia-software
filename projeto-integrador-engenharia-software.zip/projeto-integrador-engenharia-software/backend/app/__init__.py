import os

from flask import Flask, abort, jsonify, request, send_from_directory

from . import db
from .erros import Conflito, ErroValidacao, NaoEncontrado

BASE = os.path.dirname(os.path.abspath(__file__))
FRONT = os.path.abspath(os.path.join(BASE, "..", "..", "frontend"))


def create_app(config=None):
    app = Flask(__name__, static_folder=None)
    app.config.update(
        SECRET_KEY=os.environ.get("SECRET_KEY", "dev-troque-em-producao"),
        DATABASE_URL=os.environ.get("DATABASE_URL", "sqlite:///" + os.path.join(BASE, "..", "dev.db")),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("FLASK_ENV") == "production",
    )
    if config:
        app.config.update(config)

    db.init_app(app)
    with app.app_context():
        db.init_db()

    from .controllers.agendamento_controller import bp as agendamentos_bp
    from .controllers.auth_controller import bp as auth_bp
    app.register_blueprint(auth_bp)
    app.register_blueprint(agendamentos_bp)

    @app.errorhandler(ErroValidacao)
    def _422(e):
        return jsonify(erro=e.mensagem, campo=e.campo), 422

    @app.errorhandler(Conflito)
    def _409(e):
        return jsonify(erro=str(e)), 409

    @app.errorhandler(NaoEncontrado)
    def _nf(e):
        return jsonify(erro=str(e)), 404

    @app.errorhandler(404)
    def _404(_e):
        return jsonify(erro="Recurso não encontrado."), 404

    @app.errorhandler(500)
    def _500(_e):
        return jsonify(erro="Erro interno. Tente novamente em instantes."), 500

    @app.get("/")
    def index():
        return send_from_directory(FRONT, "index.html")

    @app.get("/<path:nome>")
    def estaticos(nome):
        if nome.startswith("api/"):
            abort(404)
        return send_from_directory(FRONT, nome)

    return app
