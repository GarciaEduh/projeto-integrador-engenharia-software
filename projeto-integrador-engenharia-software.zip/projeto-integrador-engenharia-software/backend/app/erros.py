class ErroValidacao(Exception):
    def __init__(self, mensagem, campo=None):
        super().__init__(mensagem)
        self.mensagem, self.campo = mensagem, campo


class Conflito(Exception):
    pass


class NaoEncontrado(Exception):
    pass
