from werkzeug.security import check_password_hash, generate_password_hash

from ..db import execute, query
from ..erros import Conflito


def criar(nome, email, senha):
    try:
        return execute("INSERT INTO usuarios (nome, email, senha_hash) VALUES (?, ?, ?)",
                       (nome, email, generate_password_hash(senha)), returning=True)
    except Conflito:
        raise Conflito("Este e-mail já está cadastrado.")


def por_id(uid):
    return query("SELECT id, nome, email FROM usuarios WHERE id = ?", (uid,), one=True)


def autenticar(email, senha):
    u = query("SELECT * FROM usuarios WHERE email = ?", (email,), one=True)
    return u if u and check_password_hash(u["senha_hash"], senha) else None


def atualizar(uid, nome, email):
    """Correcao do laudo: e-mail repetido agora vira 409 com mensagem, nao erro 500."""
    try:
        execute("UPDATE usuarios SET nome = ?, email = ? WHERE id = ?", (nome, email, uid))
    except Conflito:
        raise Conflito("Este e-mail já está em uso por outra conta.")


def trocar_senha(uid, atual, nova):
    u = query("SELECT senha_hash FROM usuarios WHERE id = ?", (uid,), one=True)
    if not u or not check_password_hash(u["senha_hash"], atual):
        return False
    execute("UPDATE usuarios SET senha_hash = ? WHERE id = ?", (generate_password_hash(nova), uid))
    return True
