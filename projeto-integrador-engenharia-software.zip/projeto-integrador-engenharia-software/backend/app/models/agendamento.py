from ..db import execute, query
from ..erros import Conflito, ErroValidacao, NaoEncontrado
from ..validators import agora

STATUS = ("agendado", "concluido", "cancelado")
COLUNAS = {"data": "a.data_hora", "servico": "s.nome", "status": "a.status"}
BASE = "FROM agendamentos a JOIN servicos s ON s.id = a.servico_id"


def servicos():
    return query("SELECT id, nome, duracao_min, preco FROM servicos ORDER BY id")


def listar(uid, pagina, por_pagina, status=None, busca=None, ordem="data", direcao="desc"):
    onde, params = ["a.usuario_id = ?"], [uid]
    if status in STATUS:
        onde.append("a.status = ?")
        params.append(status)
    if busca:
        onde.append("LOWER(s.nome) LIKE ?")
        params.append(f"%{busca.lower()}%")
    w = " AND ".join(onde)
    total = query(f"SELECT COUNT(*) AS n {BASE} WHERE {w}", params, one=True)["n"]
    col = COLUNAS.get(ordem, "a.data_hora")  # lista branca: sem SQL injection
    dir_ = "ASC" if direcao == "asc" else "DESC"
    itens = query(
        f"SELECT a.id, a.data_hora, a.status, a.observacao, s.nome AS servico, s.preco, s.duracao_min "
        f"{BASE} WHERE {w} ORDER BY {col} {dir_}, a.id DESC LIMIT ? OFFSET ?",
        params + [por_pagina, (pagina - 1) * por_pagina])
    return {"itens": itens, "total": total, "pagina": pagina,
            "paginas": max(1, -(-total // por_pagina))}


def criar(uid, servico_id, data_hora, observacao):
    if not query("SELECT id FROM servicos WHERE id = ?", (servico_id,), one=True):
        raise ErroValidacao("Escolha um serviço válido.", "servico_id")
    try:
        return execute("INSERT INTO agendamentos (usuario_id, servico_id, data_hora, observacao) "
                       "VALUES (?, ?, ?, ?)", (uid, servico_id, data_hora, observacao), returning=True)
    except Conflito:
        raise Conflito("Esse horário já está ocupado. Escolha outro.")


def mudar_status(uid, ag_id, status):
    if execute("UPDATE agendamentos SET status = ? WHERE id = ? AND usuario_id = ?",
               (status, ag_id, uid)) == 0:
        raise NaoEncontrado("Agendamento não encontrado.")


def excluir(uid, ag_id):
    if execute("DELETE FROM agendamentos WHERE id = ? AND usuario_id = ?", (ag_id, uid)) == 0:
        raise NaoEncontrado("Agendamento não encontrado.")


def resumo(uid):
    por_status = {r["status"]: r["n"] for r in query(
        "SELECT status, COUNT(*) AS n FROM agendamentos WHERE usuario_id = ? GROUP BY status", (uid,))}
    por_servico = query(
        f"SELECT s.nome AS servico, COUNT(*) AS n {BASE} "
        "WHERE a.usuario_id = ? AND a.status <> 'cancelado' GROUP BY s.nome ORDER BY n DESC, s.nome", (uid,))
    proximo = query(
        f"SELECT a.id, a.data_hora, s.nome AS servico {BASE} "
        "WHERE a.usuario_id = ? AND a.status = 'agendado' AND a.data_hora >= ? "
        "ORDER BY a.data_hora LIMIT 1", (uid, agora().strftime("%Y-%m-%d %H:%M")), one=True)
    return {"por_status": {s: por_status.get(s, 0) for s in STATUS},
            "por_servico": por_servico, "proximo": proximo}
