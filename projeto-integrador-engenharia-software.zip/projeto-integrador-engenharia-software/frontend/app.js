const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmtData = (s) => new Date(s.replace(" ", "T")).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
const moeda = (v) => Number(v).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const ROTULO = { agendado: "Agendado", concluido: "Concluído", cancelado: "Cancelado" };
const estado = { user: null, pagina: 1, paginas: 1 };

async function api(caminho, { metodo = "GET", corpo } = {}) {
  const r = await fetch("/api" + caminho, {
    method: metodo, credentials: "same-origin",
    headers: corpo ? { "Content-Type": "application/json" } : {},
    body: corpo ? JSON.stringify(corpo) : undefined,
  });
  let dados = null;
  try { dados = await r.json(); } catch { /* resposta sem corpo */ }
  if (!r.ok) {
    const e = new Error((dados && dados.erro) || "Algo deu errado. Tente novamente.");
    e.status = r.status; e.campo = dados && dados.campo;
    throw e;
  }
  return dados;
}

function toast(msg, erro = false) {
  const p = document.createElement("p");
  p.textContent = msg;
  if (erro) p.className = "erro-toast";
  $("#toast").append(p);
  setTimeout(() => p.remove(), 4000);
}

/* Correcao do laudo: o botao fica desabilitado durante a requisicao (evita duplo clique) */
async function ocupado(botao, fn) {
  if (botao.disabled) return;
  botao.disabled = true; botao.setAttribute("aria-busy", "true");
  try { return await fn(); } finally { botao.disabled = false; botao.removeAttribute("aria-busy"); }
}

function mostrarErro(form, e) {
  $(".erro", form).textContent = e.message;
  $$("[aria-invalid]", form).forEach((i) => i.removeAttribute("aria-invalid"));
  if (e.campo && form.elements[e.campo]) form.elements[e.campo].setAttribute("aria-invalid", "true");
}
const limparErro = (form) => mostrarErro(form, { message: "" });

function submeter(form, fn) {
  form.addEventListener("submit", (ev) => {
    ev.preventDefault();
    limparErro(form);
    ocupado($("button[type=submit]", form), async () => {
      try { await fn(Object.fromEntries(new FormData(form))); } catch (e) { mostrarErro(form, e); }
    });
  });
}

function confirmar(msg) {
  return new Promise((resolve) => {
    const d = $("#confirmar");
    $("#confirmar-msg").textContent = msg;
    d.returnValue = "";
    d.addEventListener("close", () => resolve(d.returnValue === "ok"), { once: true });
    d.showModal();
  });
}

/* ---------- navegacao ---------- */
function ir(nome) {
  $$(".view").forEach((v) => (v.hidden = v.id !== nome));
  $$("#menu [data-view]").forEach((b) => (b.dataset.view === nome ? b.setAttribute("aria-current", "page") : b.removeAttribute("aria-current")));
  if (nome === "painel") carregarPainel();
  if (nome === "agendamentos") { prepararNovo(); carregarLista(); }
  if (nome === "perfil") { const f = $("#form-perfil"); f.nome.value = estado.user.nome; f.email.value = estado.user.email; }
}

function entrar(user) {
  estado.user = user;
  $("#auth").hidden = true; $("#menu").hidden = false;
  ir("painel");
}

function sair() {
  estado.user = null;
  $$(".view").forEach((v) => (v.hidden = true));
  $("#menu").hidden = true; $("#auth").hidden = false;
}

/* ---------- painel ---------- */
async function carregarPainel() {
  const d = await api("/dashboard");
  $("#proximo").innerHTML = d.proximo
    ? `Próximo horário: <strong>${esc(fmtData(d.proximo.data_hora))}</strong> — ${esc(d.proximo.servico)}`
    : `<span class="vazio">Você não tem horários futuros. Vá em Agendamentos para marcar o próximo.</span>`;
  $("#contadores").innerHTML = Object.entries(d.por_status)
    .map(([s, n]) => `<div class="cartao"><b>${n}</b>${ROTULO[s]}</div>`).join("");
  const max = Math.max(1, ...d.por_servico.map((s) => s.n));
  $("#grafico").innerHTML = d.por_servico.length
    ? d.por_servico.map((s) => `<div class="barra"><span>${esc(s.servico)}</span><div style="width:${(s.n / max) * 100}%"></div><b>${s.n}</b></div>`).join("")
    : `<p class="vazio">Nenhum agendamento ainda.</p>`;
}

/* ---------- agendamentos ---------- */
let servicosCarregados = false;
async function prepararNovo() {
  const f = $("#form-novo");
  if (!servicosCarregados) {
    const lista = await api("/servicos");
    f.servico_id.innerHTML = lista.map((s) => `<option value="${s.id}">${esc(s.nome)} (${s.duracao_min} min, ${moeda(s.preco)})</option>`).join("");
    servicosCarregados = true;
  }
  const n = new Date(); n.setMinutes(n.getMinutes() - n.getTimezoneOffset());
  f.data_hora.min = n.toISOString().slice(0, 16); // validacao de data futura no front-end
}

async function carregarLista() {
  const f = $("#filtros");
  const [ordem, direcao] = f.ordem.value.split("|");
  const qs = new URLSearchParams({ pagina: estado.pagina, por_pagina: 8, q: f.q.value, status: f.status.value, ordem, direcao });
  const r = await api("/agendamentos?" + qs);
  estado.paginas = r.paginas;
  $("#lista").innerHTML = r.itens.length ? r.itens.map((a) => `
    <tr>
      <td data-rotulo="Data e hora">${esc(fmtData(a.data_hora))}</td>
      <td data-rotulo="Serviço">${esc(a.servico)}</td>
      <td data-rotulo="Valor">${moeda(a.preco)}</td>
      <td data-rotulo="Status"><span class="status ${a.status}">${ROTULO[a.status]}</span></td>
      <td data-rotulo="Ações"><div class="acoes">
        ${a.status === "agendado" ? `<button data-acao="concluido" data-id="${a.id}">Concluir</button><button data-acao="cancelado" data-id="${a.id}">Cancelar</button>` : ""}
        <button data-acao="excluir" data-id="${a.id}">Excluir</button></div></td>
    </tr>`).join("") : `<tr><td colspan="5" class="vazio">Nenhum agendamento encontrado. Use o formulário acima para marcar um horário.</td></tr>`;
  $("#pag-info").textContent = `Página ${r.pagina} de ${r.paginas} (${r.total} no total)`;
  $("#pag-ant").disabled = r.pagina <= 1;
  $("#pag-prox").disabled = r.pagina >= r.paginas;
}

$("#lista").addEventListener("click", (ev) => {
  const b = ev.target.closest("button[data-acao]");
  if (!b) return;
  ocupado(b, async () => {
    const { acao, id } = b.dataset;
    try {
      if (acao === "excluir") {
        if (!(await confirmar("Excluir este agendamento? Essa ação não pode ser desfeita."))) return;
        await api(`/agendamentos/${id}`, { metodo: "DELETE" });
        toast("Agendamento excluído.");
      } else {
        await api(`/agendamentos/${id}/status`, { metodo: "PATCH", corpo: { status: acao } });
        toast(acao === "concluido" ? "Agendamento concluído." : "Agendamento cancelado.");
      }
      await carregarLista();
    } catch (e) { toast(e.message, true); }
  });
});

let espera;
$("#filtros").addEventListener("input", () => { clearTimeout(espera); espera = setTimeout(() => { estado.pagina = 1; carregarLista(); }, 300); });
$("#pag-ant").addEventListener("click", () => { estado.pagina--; carregarLista(); });
$("#pag-prox").addEventListener("click", () => { estado.pagina++; carregarLista(); });

submeter($("#form-novo"), async (d) => {
  await api("/agendamentos", { metodo: "POST", corpo: { servico_id: d.servico_id, data_hora: d.data_hora, observacao: d.observacao } });
  $("#form-novo").reset();
  toast("Agendamento criado.");
  estado.pagina = 1;
  await carregarLista();
});

/* ---------- conta ---------- */
submeter($("#form-login"), async (d) => entrar(await api("/auth/login", { metodo: "POST", corpo: d })));
submeter($("#form-cadastro"), async (d) => { entrar(await api("/auth/register", { metodo: "POST", corpo: d })); toast("Conta criada. Bem-vindo!"); });
submeter($("#form-perfil"), async (d) => {
  estado.user = await api("/perfil", { metodo: "PUT", corpo: d });
  toast("Dados atualizados.");
});
submeter($("#form-senha"), async (d) => {
  await api("/perfil/senha", { metodo: "PUT", corpo: d });
  $("#form-senha").reset();
  toast("Senha alterada.");
});

$$("[data-aba]").forEach((b) => b.addEventListener("click", () => {
  $$("[data-aba]").forEach((x) => x.setAttribute("aria-selected", x === b));
  $("#form-login").hidden = b.dataset.aba !== "login";
  $("#form-cadastro").hidden = b.dataset.aba !== "cadastro";
}));
$$("#menu [data-view]").forEach((b) => b.addEventListener("click", () => ir(b.dataset.view)));
$("#btn-sair").addEventListener("click", async () => { await api("/auth/logout", { metodo: "POST" }); sair(); });

api("/auth/me").then(entrar).catch(() => {});
