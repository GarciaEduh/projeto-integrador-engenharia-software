# Laudo de qualidade

## 1. Verificação e validação (modelo em V)
| Nível | Como foi feito | Evidência |
|---|---|---|
| Teste unitário | `python -m unittest -v` em `backend/tests` (validações) | _print do terminal em `evidencias/`_ |
| Teste de integração | Mesma suíte, chamando a API com banco SQLite temporário | _print do terminal_ |
| Teste de sistema | Uso completo no navegador (desktop e celular) | _prints das telas_ |
| Teste de aceitação | Testes dos 5 colegas (formulário em `formulario-de-teste.md`) | _formulários preenchidos + prints_ |

## 2. Erros encontrados e correções
Preencha **somente com o que os colegas realmente relataram**. Guarde os prints em `evidencias/`.

| # | Testador | Data | Erro encontrado (com print) | Correção aplicada | Arquivo/commit | Reteste |
|---|---|---|---|---|---|---|
| 1 | | | | | | |
| 2 | | | | | | |
| 3 | | | | | | |
| 4 | | | | | | |
| 5 | | | | | | |

## 3. Funcionalidades não implementadas
Recuperação de senha por e-mail, upload de foto de perfil, exportação em PDF, notificações em tempo real,
tema claro/escuro manual, filtros combinados avançados e integração com pagamentos.
