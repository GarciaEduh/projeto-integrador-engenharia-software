# Manual de uso

1. **Criar conta:** na tela inicial, abra *Criar conta*, informe nome, e-mail e senha (8+ caracteres com letras e números).
2. **Agendar:** em *Agendamentos*, escolha o serviço, a data/hora (futura, entre 08h e 20h) e clique em *Agendar*.
3. **Acompanhar:** use a busca, o filtro de status e a ordenação; navegue pelas páginas.
4. **Concluir, cancelar ou excluir:** use os botões da linha. Excluir pede confirmação.
5. **Painel:** mostra o próximo horário, totais por status e o gráfico por serviço.
6. **Perfil:** altere nome, e-mail e senha.

Para rodar o código e os testes, veja o `README.md` na raiz.
