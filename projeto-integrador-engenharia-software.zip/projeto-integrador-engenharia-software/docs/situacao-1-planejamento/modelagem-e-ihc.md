# Situação 1 — Planejamento revisado

## Escopo
Sistema web para um estabelecimento de serviços de barbearia. O cliente cadastra-se, agenda horários,
acompanha, conclui, cancela ou exclui agendamentos e consulta um painel de resumo.
Fora do escopo: pagamentos, notificações em tempo real, múltiplos profissionais.

## Requisitos
**Funcionais:** RF01 cadastro e login · RF02 editar perfil e senha · RF03 listar serviços · RF04 criar agendamento ·
RF05 listar com busca, filtro, ordenação e paginação · RF06 concluir/cancelar · RF07 excluir · RF08 painel com gráfico.

**Não funcionais:** RNF01 painel carrega em até 2 s (índices) · RNF02 interface responsiva (desktop e celular) ·
RNF03 senhas armazenadas com hash · RNF04 mensagens de erro claras · RNF05 sem horários duplicados.

**Regras de negócio:** RN01 data/hora deve ser futura · RN02 atendimento das 08h às 20h ·
RN03 um horário só pode ter um agendamento ativo · RN04 cada cliente vê apenas os seus agendamentos.

## Casos de uso
```mermaid
flowchart LR
  C([Cliente]) --> UC1(Criar conta / Entrar)
  C --> UC2(Editar perfil e senha)
  C --> UC3(Agendar serviço)
  C --> UC4(Consultar agendamentos)
  C --> UC5(Concluir / Cancelar / Excluir)
  C --> UC6(Ver painel)
  UC3 -.inclui.-> V(Validar data e horário)
```

## Diagrama de classes (persistência)
```mermaid
classDiagram
  class Usuario { +int id +string nome +string email +string senha_hash +datetime criado_em }
  class Servico { +int id +string nome +int duracao_min +decimal preco }
  class Agendamento { +int id +datetime data_hora +string status +string observacao +datetime criado_em }
  Usuario "1" --> "0..*" Agendamento : faz
  Servico "1" --> "0..*" Agendamento : é do tipo
```

## Diagrama de sequência — criar agendamento
```mermaid
sequenceDiagram
  actor C as Cliente
  participant V as View (app.js)
  participant K as Controller
  participant M as Model
  participant B as PostgreSQL
  C->>V: preenche e clica em Agendar
  V->>V: desabilita botão, valida data mínima
  V->>K: POST /api/agendamentos
  K->>K: valida serviço, data futura, horário comercial
  K->>M: criar(...)
  M->>B: INSERT
  B-->>M: ok ou violação do índice único
  M-->>K: id ou Conflito
  K-->>V: 201 ou 409/422 com mensagem
  V-->>C: toast de sucesso ou erro no formulário
```

## IHC — telas e mensagens
Telas: Entrar/Criar conta · Painel · Agendamentos (formulário, filtros, tabela, paginação) · Perfil.
Princípios aplicados (material teórico): interface clara e consistente, feedback imediato (toasts),
ações reversíveis ou confirmadas (modal antes de excluir), erros sem culpar o usuário e dizendo como corrigir.

| Situação | Mensagem |
|---|---|
| Login inválido | E-mail ou senha incorretos. |
| Data passada | Escolha uma data e hora no futuro. |
| Fora do expediente | Atendemos das 08h às 20h. |
| Horário ocupado | Esse horário já está ocupado. Escolha outro. |
| E-mail repetido | Este e-mail já está em uso por outra conta. |

## Projeto de dados
Conceitual: Usuario 1—N Agendamento N—1 Servico. Lógico: 3ª forma normal (sem atributos repetidos nem dependências transitivas).
Físico: `database/schema.sql`.

### Dicionário de dados
**usuarios**
| Campo | Tipo | Restrições | Descrição |
|---|---|---|---|
| id | SERIAL | PK | Identificador |
| nome | VARCHAR(100) | NOT NULL | Nome do cliente |
| email | VARCHAR(150) | NOT NULL, UNIQUE | Login (minúsculo) |
| senha_hash | VARCHAR(255) | NOT NULL | Hash da senha |
| criado_em | TIMESTAMP | NOT NULL, default agora | Data de cadastro |

**servicos**
| Campo | Tipo | Restrições | Descrição |
|---|---|---|---|
| id | SERIAL | PK | Identificador |
| nome | VARCHAR(80) | NOT NULL, UNIQUE | Nome do serviço |
| duracao_min | INTEGER | CHECK 10–240 | Duração em minutos |
| preco | NUMERIC(8,2) | CHECK ≥ 0 | Valor em reais |

**agendamentos**
| Campo | Tipo | Restrições | Descrição |
|---|---|---|---|
| id | SERIAL | PK | Identificador |
| usuario_id | INTEGER | FK usuarios, ON DELETE CASCADE | Dono do agendamento |
| servico_id | INTEGER | FK servicos | Serviço contratado |
| data_hora | TIMESTAMP | NOT NULL | Início do atendimento |
| status | VARCHAR(12) | CHECK agendado/concluido/cancelado | Situação |
| observacao | VARCHAR(200) | opcional | Texto livre |
| criado_em | TIMESTAMP | NOT NULL, default agora | Criação do registro |

Índices: `(usuario_id, data_hora)`, `(status)` e índice único parcial em `data_hora` onde `status <> 'cancelado'`.
